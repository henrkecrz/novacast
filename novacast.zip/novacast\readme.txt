=== Novacast ===
Contributors: henrkecrz
Tags: podcast, audio, player, shortcode, youtube, spotify, react
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 0.5.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Gerencie episódios de podcast no WordPress e exiba players no frontend.

== Description ==

Novacast cria um painel de episódios de podcast dentro do WordPress. Cada episódio pode ter título, descrição, capa, URL de áudio, duração, fonte de reprodução e status de exibição.

O plugin oferece o shortcode [novacast_player] para exibir episódios no frontend com player responsivo renderizado em React usando o wp.element do WordPress.

Fontes de reprodução disponíveis:

* Áudio próprio via player customizado em React.
* YouTube via embed oficial.
* Spotify via embed oficial.

A sincronização com YouTube e Spotify importa metadados públicos e cria/atualiza episódios no WordPress. O plugin não baixa áudio dessas plataformas.

== Installation ==

1. Envie a pasta Novacast para wp-content/plugins/.
2. Ative o plugin no painel do WordPress.
3. Acesse Novacast > Adicionar novo para cadastrar episódios manualmente.
4. Acesse Novacast > Sincronização para configurar YouTube e Spotify.
5. Use o shortcode [novacast_player] em uma página ou post.

== Shortcodes ==

Exibir os últimos episódios:

[novacast_player]

Exibir até 5 episódios:

[novacast_player limit="5"]

Exibir com tema escuro inicial:

[novacast_player theme="dark"]

Exibir um episódio específico:

[novacast_player id="123"]

== YouTube ==

Para sincronizar YouTube, informe uma YouTube API Key e o ID de uma playlist pública em Novacast > Sincronização.

Os episódios importados usam o embed oficial do YouTube no frontend.

== Spotify ==

Para sincronizar Spotify, informe Client ID, Client Secret e o ID ou URL de um show em Novacast > Sincronização.

Os episódios importados usam o embed oficial do Spotify no frontend.

= 0.5.0 =
* Glassmorphism aprimorado: fundos mais profundos, blur intensificado e sombras refinadas.
* Adicionados orbes de fundo animados com gradientes azul/violeta.
* CSS refatorado com variáveis de design system para consistência visual.
* Player React substituiu emoji por ícone SVG para maior fidelidade visual.
* Painel administrativo recebeu cantos arredondados e backdrop-filter sutil.
* Novos tokens CSS: --novacast-glass-bg, --novacast-glass-border, --novacast-glass-blur, etc.

== Changelog ==

= 0.4.1 =
* Visual do player React refinado para uma aparência mais premium.
* Adicionado waveform visual no player principal.
* Adicionados botões de avançar 30s e voltar 10s.
* Lista de episódios redesenhada em linhas compactas com mini waveform.
* Capa do episódio recebeu overlay, botão visual de play e acabamento mais editorial.

= 0.4.0 =
* Frontend do player migrado para React usando wp.element do WordPress.
* PHP agora prepara os dados dos episódios e envia JSON para o componente React.
* Adicionado bundle Novacast React Player sem necessidade de etapa Node/build.
* Mantido suporte a áudio próprio, YouTube e Spotify.

= 0.3.3 =
* Substituído o player nativo de áudio por um player customizado premium.
* Adicionados controles de play/pause, progresso, busca e mute via JavaScript.
* Botão de tema redesenhado com ícones de sol e lua.
* Aplicado glassmorphism suave no frontend.
* Refinada a aparência para maior semelhança com o mockup premium.

= 0.3.2 =
* Painel administrativo de episódios redesenhado em cards interativos.
* Adicionada seleção visual da fonte de reprodução.
* Adicionada detecção automática da duração do áudio próprio.
* Adicionado CSS administrativo dedicado.

= 0.3.1 =
* Aplicado refinamento visual inspirado no mockup premium do player.
* Adicionada prévia visual em SVG no diretório docs/.
* Atualizado o README do GitHub com imagem de apresentação do player.

= 0.3.0 =
* Adicionado player principal em destaque com o episódio mais recente.
* Adicionada lista de episódios abaixo do destaque.
* Adicionado botão "Ver todos os episódios".
* Adicionada opção de alternar entre tema claro e escuro no frontend.
* Adicionados ícone de play, número do episódio e data.
* Adicionado botão para carregar ou escolher áudio pela biblioteca de mídia no cadastro do episódio.

= 0.2.2 =
* Novo visual premium para o frontend do player.
* Cabeçalho com identidade azul e branca da Novacap.
* Cards de episódios com visual mais refinado.
* Selo de origem do episódio e destaque "Ouça agora".

= 0.2.1 =
* Atualizada a versão para facilitar substituição/atualização pelo painel do WordPress.
* Mantidos os ajustes visuais da seção Novacast no frontend.

= 0.2.0 =
* Adicionada seleção de fonte de reprodução por episódio.
* Adicionado suporte a YouTube Embed no frontend.
* Adicionado suporte a Spotify Embed no frontend.
* Adicionada tela Novacast > Sincronização.
* Adicionada sincronização manual com playlist do YouTube.
* Adicionada sincronização manual com show do Spotify.

= 0.1.0 =
* Estrutura inicial do plugin.
* Cadastro de episódios como Custom Post Type.
* Campos de URL de áudio, duração e status ativo.
* Shortcode de player no frontend.
